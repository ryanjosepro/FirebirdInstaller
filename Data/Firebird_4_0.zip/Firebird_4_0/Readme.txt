
====================================
Firebird 4.0.0     (Alpha/Beta Windows Build)
====================================


o Introduction
o Intended Users
o Reporting Bugs


Introduction
============

Welcome to Firebird 4.0.


Intended Users
==============

This is an alpha or beta release of Firebird 4.0.
It is intended for test purposes only and is not 
considered ready for use in production. 

 o DO NOT STORE CRITICAL DATA USING THIS TEST VERSION
   Databases created by this release may not be 
   compatible with future releases of Firebird 4.0.

 o Please make sure you read the installation
   readme and the release notes.


Reporting Bugs
==============

This is an experimental version.

DO NOT REPORT A BUG IN THIS RELEASE
unless you really know what you are doing.

Check first on the firebird-devel list. If you 
don't know where the firebird-devel list is then 
you shouldn't be using this version of Firebird!

Please don't use the Firebird-devel list for 
technical support unless the question specifically 
relates to a new feature in Firebird 4.0


Happy Testing!

From the Firebird team.

